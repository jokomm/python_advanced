##Web Scraping With Python: Beautiful Soup

Web Scraping from ordi.eu using BeautifulSoup

## Prerequisites
Install the Beautiful Soup library using your terminal.
The best way to install beautiful soup is via pip:

    !pip3 install beautifulsoup4


## How it works:
Run scraper.py It will scrape tablets and e-readers section on ordi.eu and write the data to a .jason file.